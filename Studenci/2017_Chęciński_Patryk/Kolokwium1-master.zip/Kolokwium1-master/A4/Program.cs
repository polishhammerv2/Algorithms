﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A4 {
    class Program {
        static void Main(string[] args) {

            int ile;
            bool fail = Int32.TryParse(Console.ReadLine(), out ile);

            if (!fail || ile < 0 || ile > 100) {
                Console.WriteLine("Nieprawidłowe dane wejściowe");
                Console.ReadKey();
                return;
            }

            if (ile == 100) {
                Console.Write('C');
            }
            else {

                int X = ile / 10;

                if (X == 4)
                    Console.Write("XL");
                else if (X == 9)
                    Console.Write("XC");

                else if (X < 4) {
                    for (int i = 0; i != X; i++) {
                        Console.Write("X");
                    }
                }
                else {
                    Console.Write("L");

                    for (int i = 0; i != X - 5; i++) {
                        Console.Write("X");
                    }
                }

                int I = ile % 10;

                if (I == 4)
                    Console.Write("IV");
                else if (I == 9)
                    Console.Write("IX");
                else if (I < 4) {
                    for (int i = 0; i != I; i++) {
                        Console.Write("I");
                    }
                }
                else {
                    Console.Write("V");

                    for (int i = 0; i != I - 5; i++) {
                        Console.Write("I");
                    }
                }
            }

            Console.ReadKey();
        }
    }
}