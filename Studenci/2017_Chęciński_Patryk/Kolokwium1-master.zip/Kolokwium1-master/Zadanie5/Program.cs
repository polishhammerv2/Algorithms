﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadanie5 {
    class Program {
        static void Main(string[] args) {

            int n;
            bool fail = Int32.TryParse(Console.ReadLine(), out n);

            if (!fail || n < 1 || n > 1000) {
                Console.WriteLine("Nieprawidłowe dane wejściowe");
                Console.ReadKey();
                return;
            }

            int[] liczby = new int[n];
            for(int i=0; i != n; i++) {
                liczby[i] = Int32.Parse(Console.ReadLine());
            }

            int dziel3=0, dziel5=0;
            foreach (int el in liczby) {
                if (el % 3 == 0) dziel3++;
                if (el % 5 == 0) dziel5++;
            }

            Console.WriteLine("Podzielnych przez 3: {0}\nPodzielnych przez 5: {1}", dziel3, dziel5);
            Console.ReadKey();
        }
    }
}
