﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadanie4 {
    class Program {
        static void Main(string[] args) {
            int n, suma=0;
            bool fail = Int32.TryParse(Console.ReadLine(), out n);

            if (!fail || n < 0) {
                Console.WriteLine("Nieprawidłowe dane wejściowe");
                Console.ReadKey();
                return;
            }

            while (n>0) {
                suma += n % 10;
                n = n / 10;
            }

            Console.WriteLine(suma);
            Console.ReadKey();

        }
    }
}
