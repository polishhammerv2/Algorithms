﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kolokwium {
    class Program {
        static void Main(string[] args) {
            double r, h;
            Console.WriteLine("Podaj r:");
            double.TryParse(Console.ReadLine(), out r);
            Console.WriteLine("Podaj h:");
            double.TryParse(Console.ReadLine(), out h);

            if(r <= 0 || h <= 0) {
                Console.WriteLine("Nieprawidlowe dane wejsciowe");
                Console.ReadKey();
                return;
            }

            Console.WriteLine("Objętoś wynosi {0}", Math.PI * Math.Pow(r, 2) * h / 3.0);
            Console.ReadKey();
        }
    }
}
