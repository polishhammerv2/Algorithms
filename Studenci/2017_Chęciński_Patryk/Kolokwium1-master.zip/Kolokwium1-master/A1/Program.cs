﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1 {
    class Program {
        static void Main(string[] args) {

            int nm;
            bool fail = Int32.TryParse(Console.ReadLine(), out nm);

            if (!fail || nm < 0) {
                Console.WriteLine("Nieprawidłowe dane wejściowe");
                Console.ReadKey();
                return;
            }

            int m = nm * 1852;

            if(m > 15000) {
                Console.WriteLine("{0}nm = {1}km", nm, m/1000); // mn, (double) m/1000 <- jeśli chcemy precyzyjniej
            }
            else {
                Console.WriteLine("{0}nm = {1}m", nm, m);
            }

            Console.ReadKey();
        }
    }
}
