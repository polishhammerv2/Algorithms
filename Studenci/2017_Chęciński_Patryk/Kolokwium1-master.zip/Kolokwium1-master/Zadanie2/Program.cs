﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadanie2 {
    class Program {
        static void Main(string[] args) {
            int ile;
            bool fail = Int32.TryParse(Console.ReadLine(), out ile);

            if (!fail || ile < 0 || ile >= 100) {
                Console.WriteLine("Nieprawidłowe dane wejściowe");
                Console.ReadKey();
                return;
            }

            int dzies = ile - ile % 10;
            int jedn = ile % 10;

            switch (dzies) {
                case 90:
                    Console.Write("Dziewiędziesiąt ");
                    break;

                case 80:
                    Console.Write("Osiemdziesiąt ");
                    break;

                case 70:
                    Console.Write("Siedemdziesiąt ");
                    break;

                case 60:
                    Console.Write("Sześćdziesiąt ");
                    break;

                case 50:
                    Console.Write("Pięćdziesiąt ");
                    break;

                case 40:
                    Console.Write("Czterdzieści ");
                    break;

                case 30:
                    Console.Write("Trzydzieści ");
                    break;

                case 20:
                    Console.Write("Dwadzieścia ");
                    break;

                case 10: {
                        switch (jedn) {
                            case 9: Console.Write("Dziewiętnaście"); break;
                            case 8: Console.Write("Osiemnaście"); break;
                            case 7: Console.Write("Siedemnaście"); break;
                            case 6: Console.Write("Szesnaście"); break;
                            case 5: Console.Write("Piętnaście"); break;
                            case 4: Console.Write("Czternaście"); break;
                            case 3: Console.Write("Trzynaście"); break;
                            case 2: Console.Write("Dwanaście"); break;
                            case 1: Console.Write("Jedenaście"); break;

                            case 0: Console.Write("Dziesięć"); break; // ur special my friend
                        }
                        break;
                    }
            }

            if (dzies != 10) {
                switch (jedn) {
                    case 9: Console.Write("dziewięć"); break;
                    case 8: Console.Write("osiem"); break;
                    case 7: Console.Write("siedem"); break;
                    case 6: Console.Write("sześć"); break;
                    case 5: Console.Write("pięć"); break;
                    case 4: Console.Write("cztery"); break;
                    case 3: Console.Write("trzy"); break;
                    case 2: Console.Write("dwa"); break;
                    case 1: Console.Write("jeden"); break;
                }
            }



            Console.ReadKey();
       }
    }
}
