﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A2 {
    class Program {
        static void Main(string[] args) {

            while (true) {
                char[] znaki = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

                string liczba_hex = Console.ReadLine().ToUpper();
                char[] tablica_hex = liczba_hex.ToCharArray();

                // liczenie od końca
                Array.Reverse(tablica_hex);

                int base_10 = 0; 
                
                if (liczba_hex.Length != 4) {
                    Console.WriteLine("Błąd: nieprawidłowa ilość znaków");
                    break;
                }

                for(int i = 0; i < 4; i++){

                    int wartosc = Array.IndexOf(znaki, tablica_hex[i]);

                    if (wartosc == -1) {
                        Console.WriteLine("Błąd: podano nieprawidłowy znak");
                        break;
                    }

                    base_10 = base_10 + wartosc * (int)Math.Pow(16, i);
                }

                Console.WriteLine("{0} = {1}", liczba_hex, base_10);
                Console.WriteLine("Jeszcze raz? y/n");

                if (Console.ReadKey(true).KeyChar == 'n') {
                    break;
                }
            }

            Console.ReadKey();
        }
    }
}
