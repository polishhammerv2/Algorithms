﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A5 {
    class Program {
        static void Main(string[] args) {

            int n;
            bool fail = Int32.TryParse(Console.ReadLine(), out n);

            if (!fail || n < 1 || n > 1000) {
                Console.WriteLine("Nieprawidłowe dane wejściowe");
                Console.ReadKey();
                return;
            }

            Random rand = new Random();
            int[] liczby = new int[n];
            int dziel2=0, dziel7=0;

            for(int i = 0; i != n; i++) {
                liczby[i] = rand.Next(0, 1001);
            }

            // nawet nie wiem, czy jest sens wklepywać to do tablicy - zadanie tego nie określa
            foreach(int los in liczby) {
                if (los % 2 == 0) dziel2++;
                if (los % 7 == 0) dziel7++;
            }

            Console.WriteLine("Podzielnych przez 2: {0}\nPodzielnych przez 7: {1}", dziel2, dziel7);
            Console.ReadKey();
        }
    }
}
