﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A3 {
    class Program {
        static void Main(string[] args) {

            int n;
            bool fail = Int32.TryParse(Console.ReadLine(), out n);

            if (!fail || n < 4) {
                Console.WriteLine("Nieprawidłowe dane wejściowe");
                Console.ReadKey();
                return;
            }

            int h = 0;
            while (h < n) {

                for (int i = 0; i < h; i++) {
                    Console.Write(" ");
                }

                for (int i = 0; i < n - h; i++) {
                    if (i == 0 || h == 0 || i == n - h - 1) {
                        Console.Write("A");
                    }
                    else {
                        Console.Write("Y");
                    }

                }

                Console.WriteLine();

                h++;
            }

            Console.ReadKey();
        }
    }
}
